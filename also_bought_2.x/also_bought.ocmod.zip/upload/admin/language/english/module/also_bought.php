<?php
// Heading
$_['heading_title']    = 'Also Bought';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified also bought module!';
$_['text_edit']        = 'Edit Also Bought Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_heading']     = 'Heading';
$_['entry_quantity']     = 'Quantity';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify category module!';
